/*
 * Eric Vien
 * 12/8/2023
 */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <ctime>
using namespace std;

const int N = 14; //Number of cities in cities.txt
typedef pair<double,double> Point; //<latitude,longitude> of a city
vector<Point> P(N), best; //P - current solution, best - best solution
map<Point, int> cities; //Point (latitude,longitude) -> index of city in cities.txt order
string cityNames[] = {"New York City",
                      "Chicago",
                      "Los Angeles",
                      "Toronto",
                      "Houston",
                      "Montreal",
                      "Mexico City",
                      "Vancouver",
                      "Atlanta",
                      "Denver",
                      "San Juan",
                      "New Orleans",
                      "Miami",
                      "Kansas City"}; //Index of a city -> city name

//Calculates "distance"
//Units are lat./long. "degrees" on an x-y plane
//to simplify calculations (not mi/km on globe)
double dist(int i, int j)
{
  double dx = P[(i+N)%N].first - P[(j+N)%N].first;
  double dy = P[(i+N)%N].second - P[(j+N)%N].second;
  return sqrt(dx*dx + dy*dy);
}

bool refine(double &len)
{
    vector<Point> saveVec = P;
    int diagIndex = 2;
    double edgeSum, totalSum;
    for (int e = 0; e < N; e++) {
        while (P[(e + diagIndex) % N] != P[e]) {
            totalSum = 0;
            int edge2node1Index = (e + diagIndex) % N;
            reverse(P.begin() + ((e + 1) % N), P.begin() + (edge2node1Index + 1) % N);

            for (int v = 0; v < N; v++) {
                edgeSum = 0;
                edgeSum += dist(v, (v + 1) % N);
                totalSum += edgeSum;
            }

            if (totalSum < len) {
                len = totalSum;
                best = P;
                return true;
            }
            P = saveVec;

            diagIndex++;
        }
        diagIndex = 2;
    }

    return false;
}

//Returns best length for test case
double tspRefine()
{
  double best_len = 999999999;
  ifstream fin("cities.txt");
  for (int i=0; i<N; i++)
  {
    fin >> P[i].first >> P[i].second;
    cities[P[i]] = i;
  }
  const int ITERATIONS = 100;
  srand(time(NULL));

  for (int numIter = 0; numIter < ITERATIONS; numIter++) {
      for (int e = 0; e < N; e++) {
          int randPred = rand() % (e + 1);
          Point tempPoint = P[e];
          P[e] = P[randPred];
          P[randPred] = tempPoint;
      }
      double curr_len = 999999999;

      do {
          refine(curr_len);
      } while (refine(curr_len));

      if (curr_len < best_len) {
          best_len = curr_len;
          best = P;
      }
  }

  for (auto p : best) cout << cityNames[cities[p]] << endl;
  cout << "\nTotal length: " << best_len << "\n";
  return best_len;
}


int main(void)
{

  double best_len = 999999999;
  best_len=tspRefine();
  return 0;
    double best_len = 999999999;
    clock_t start, end;
    start = clock();
    best_len=tspRefine();
    end = clock();

    //ASSERT_NEAR(best_len, 169.478, 0.001);
    if (abs(best_len - 169.478) > 0.001)
    {
        cout << "expected/correct value for best_len is 169.478 (+/- 0.001), actual value when testing " << best_len << ".\n";
        return 1;
    }
    if ((end - start) / (double)CLOCKS_PER_SEC > 3.0)
    {
        cout << "tspRefine() must return a result in less than 3 seconds, runtime is " << (end - start) / (double)CLOCKS_PER_SEC << " seconds.\n";
        return 1;
    }
    cout << "Passed" << std::endl;
    return 0;
}
