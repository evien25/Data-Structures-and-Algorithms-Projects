/*
 * Eric Vien
 * Word Ladder
 * 12/9/2023
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
using namespace std;

vector<string> V; //words from wordlist05.txt
unordered_map<string, int> dist;
unordered_map<string, string> pred;
unordered_map<string, vector<string>> nbrs;
unordered_map<string, bool> visited;
unordered_map<string, bool> isWord;

//Global variables for bfs distance, bfs predecessor, and neighboring nodes
//Should be unordered_map type

//implements breadth-first search

void loadVector(string &fileName) {
    ifstream infile(fileName);
    string word;

    while (getline(infile, word)) {
        V.push_back(word);
    }

    infile.close();

    for (string w : V) {
        isWord[w] = true;
    }
}

void make_graph(void) {
    for (string curWord : V) {
        for (int e = 0; e < curWord.size(); e++) {
            string nbr = curWord;

            for (char v = 'a'; v <= 'z'; v++) {
                if (nbr[e] != v) {
                    nbr[e] = v;

                    if (nbr != curWord && isWord[nbr]) {
                        nbrs[curWord].push_back(nbr);
                    }
                }
            }
        }
    }
}

void search(string &source) {
    queue<string> to_visit;
    to_visit.push(source);
    visited[source] = true;
    dist[source] = 0;

    while (!to_visit.empty()) {
        string curNode = to_visit.front();
        to_visit.pop();

        for (string word : nbrs[curNode]) {
            if (!visited[word]) {
                pred[word] = curNode;
                dist[word] = 1 + dist[curNode];
                visited[word] = true;
                to_visit.push(word);

            }
        }
    }
}

void generatePath(string &s, string &t, int &steps, vector<string> &p) {
    if (s != t) {
        if (pred.find(t) != pred.end()) {
            generatePath(s, pred[t], steps, p);
            p.push_back(t);
        }
        else {
            return;
        }
    }
    else {
        p.push_back(s);
    }

}

void wordLadder(string s, string t, int &steps, vector<string> &p)
{
    string fileName = "wordlist05.txt";
    loadVector(fileName);
    make_graph();
    search(s);
    generatePath(s, t, steps, p);
    steps = dist[t];
}



int main(void)
{
    int steps = 0;
    string s, t;
    vector<string> path;

    cout << "Source: ";
    cin >> s;

    cout << "Target: ";
    cin >> t;

    wordLadder(s, t, steps, path);

    if (steps == 0)
    {
        cout << "No path!\n";
    }
    else
    {
        cout << "Steps: " << steps << "\n\n";
        for (int i=0; i<path.size(); i++)
        {
            cout << path[i] << endl;
        }
    }
    return 0;

}
